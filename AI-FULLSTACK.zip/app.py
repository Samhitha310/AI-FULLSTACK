import os
from flask import Flask, request, render_template
import openai
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize OpenAI API key and Flask app
openai.api_key = os.getenv("OPENAI_API_KEY")
app = Flask(__name__)

# Cache to store previous recommendations and reduce API calls
cache = {}

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        skills = request.form.get("skills")
        interests = request.form.get("interests")
        name = request.form.get("name")  # Optional name field
        
        # Add name to the prompt if provided, else use a default generic phrase
        if name:
            prompt = f"Suggest people to connect with based on skills: {skills}, interests: {interests}. Tailor suggestions to {name}. Provide conversation starters."
        else:
            prompt = f"Suggest people to connect with based on skills: {skills}, interests: {interests}. Provide conversation starters."
        
        # Check cache for existing responses
        if prompt in cache:
            conversation = cache[prompt]
        else:
            # AI-powered recommendation generation
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                max_tokens=150,
                temperature=0.7
            )
            conversation = response["choices"][0]["message"]["content"]
            cache[prompt] = conversation

        return render_template("results.html", conversation=conversation)

    return render_template("index.html")

if __name__ == "__main__":
    app.run(debug=True)
