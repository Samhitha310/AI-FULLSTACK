document.addEventListener("DOMContentLoaded", function() {
    const form = document.querySelector("form");
    form.addEventListener("submit", function(event) {
        const skills = document.getElementById("skills").value.trim();
        const interests = document.getElementById("interests").value.trim();

        if (!skills || !interests) {
            event.preventDefault();
            alert("Please fill out both fields.");
        }
    });
});
